from flask import Flask, request
from flask_cors import CORS

from Clases.Usuario import Usuario
from Clases.Comentario import Comentario
from Metodos.Inicial import *
from Metodos.Usuario import *
from Metodos.Administrador import *

usuarios = []
usuarioEnSesion = -1
peliculas = []
comentarios = [] 

# tipo 1 para administrador
usuarios.append(Usuario('Usuario', 'Administrador', 'admin', 'admin', 1).toDict())

# tipo 2 para clientes
usuarios.append(Usuario('Ludwin', 'Morales', 'LG_Morales', '1234', 2).toDict())

# comentarios ejemplo
comentarios.append(Comentario('Super Mario Bros', 'Gerard78_0', 'estuvo bonita').toDict())
comentarios.append(Comentario('Super Mario Bros', 'Yoshi Mario Bros', 'estuvo fea porque no salí').toDict())
comentarios.append(Comentario('Los vengadores', 'Gerard78_0', 'estuvo fea').toDict())
comentarios.append(Comentario('Los vengadores', 'Jorge78_10', 'estuvo bonita').toDict())

app = Flask(__name__)
CORS(app)

@app.route('/', methods=['GET'])
def rutaInicial():
    return("Si funciona")

# ------------------------------------------------------------- INICIAL
@app.route('/registrarUsuario', methods=['POST'])
def registrarUsuario():
    respuesta = RegistrarUsuario(request.json, usuarios)
    return respuesta

@app.route('/recuperarContrasenia', methods=['POST'])
def recuperarContrasenia():
    respuesta = RecuperarContrasenia(request.json, usuarios)
    return respuesta

@app.route('/iniciarSesion', methods=['POST'])
def iniciarSesion():
    respuesta = IniciarSesion(request.json, usuarios)
    global usuarioEnSesion
    
    usuarioEnSesion = respuesta['usuarioEnSesion']
    print(usuarioEnSesion)
    return respuesta
    
# ------------------------------------------------------------- USUARIOS
@app.route('/getUsuarioEnSesion', methods=['GET'])
def getUsuarioEnSesion():
    respuesta = GetUsuarioEnSesion(usuarios, usuarioEnSesion)
    return respuesta

@app.route('/modificarPerfil', methods=['POST'])
def modificarPerfil():
    global usuarios
    respuesta = ModificarPerfil(request.json, usuarios, usuarioEnSesion)
    usuarios = respuesta['data']
    return {'data':'OK', 'status': respuesta['status']}

# ------------------------------------------------------------- ADMINISTRADOR
@app.route('/cargarPeliculas', methods=['POST'])
def cargarPeliculas():
    respuesta = CargarPeliculas(request.json)
    global peliculas
    peliculas = respuesta['data']
    return respuesta

@app.route('/getPeliculas', methods=['GET'])
def getPeliculas():
    respuesta = {'data': peliculas, 'status': 200}
    return respuesta

@app.route('/getPelicula', methods=['POST'])
def getPelicula():
    respuesta = GetPelicula(request.json, peliculas)
    return respuesta

@app.route('/editarPelicula', methods=['POST'])
def editarPelicula():
    global peliculas
    respuesta = EditarPelicula(request.json, peliculas)
    peliculas = respuesta['data']
    return {'data':'OK', 'status': respuesta['status']}

@app.route('/eliminarPelicula', methods=['POST'])
def eliminarPelicula():
    global peliculas
    respuesta = EliminarPelicula(request.json, peliculas)
    peliculas = respuesta['data']
    return {'data':'OK', 'status': respuesta['status']}

@app.route('/getComentarios', methods=['POST'])
def getComentarios():
    respuesta = GetComentarios(request.json, comentarios)
    return respuesta

@app.route('/getUsuarios', methods=['GET'])
def getUsuarios():
    respuesta = {'data': usuarios, 'status': 200}
    return respuesta

@app.route('/eliminarUsuario', methods=['POST'])
def eliminarUsuario():
    global usuarios
    respuesta = EliminarUsuario(request.json, usuarios)
    usuarios = respuesta['data']
    return {'data':'OK', 'status': respuesta['status']}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=True)

#--------------------------------------------------- Cliente
@app.route('/getUsuarios', methods=['GET'])
def getUsuarios():
    respuesta = {'data': usuarios, 'status': 200}
    return respuesta

@app.route('verPelicula', methods=['GET'])
def verPelicula():
    respuesta = {'data': verPelicula, 'status': 200}
    return respuesta

@app.route('PlayList', methods=['POST'])
def PlayList():
    respuesta = {'data': Playlist, 'status': 200}
    return respuesta

@app.route('Comentario', methods=['POST'])
def Comentario():
    respuesta = {'data':Comentario, 'status':200}
    return respuesta
